1. Add the latest OneSignalSDK.jar to the libs folder
2. Import the google-play-services_lib project into your workspace per steps 1.2 - 1.4
      https://documentation.onesignal.com/docs/installing-the-onesignal-android-sdk
2. Update onesignal_app_id and onesignal_google_project_number in the AndroidManifest.xml to yours.